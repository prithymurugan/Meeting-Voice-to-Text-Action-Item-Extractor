let recognition;

function startMeeting() {

    if (!("webkitSpeechRecognition" in window)) {
        alert("Speech recognition is not supported.");
        return;
    }

    recognition = new webkitSpeechRecognition();

    recognition.lang = "en-IN";
    recognition.continuous = true;
    recognition.interimResults = false;

    recognition.onresult = function(event) {

        for (
            let i = event.resultIndex;
            i < event.results.length;
            i++
        ) {

            document.getElementById("transcript").value +=
                event.results[i][0].transcript + " ";
        }
    };

    recognition.start();
}

function stopMeeting() {

    if (recognition) {
        recognition.stop();
    }
}

function findTasks() {

    const text =
        document.getElementById("transcript").value;

    const sentences =
        text.split(/[.!?]/);

    const tasks =
        sentences.filter(sentence =>
            /will|should|must|need to|complete|prepare/i
            .test(sentence)
        );

    const list =
        document.getElementById("tasks");

    list.innerHTML = "";

    tasks.forEach(task => {

        const li = document.createElement("li");

        li.innerText = task.trim();

        list.appendChild(li);
    });
}